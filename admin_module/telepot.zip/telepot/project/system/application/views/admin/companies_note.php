<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style1 {
	font-family: tahoma;
	font-weight: bold;
	font-size: 14px;
}
.style2 {
	font-family: tahoma;
	font-size: 12px;
	font-weight: bold;
}
.style3 {
	font-family: tahoma;
	font-size: 12px;
}
-->
</style>
</head>

<body>
{company}
<table width="385" height="91" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="34" colspan="2" align="center" bgcolor="#F2F2F2"><span class="style1">{name}</span></td>
  </tr>
  <tr>
    <td height="7" colspan="2" align="center" valign="top" class="style2">&nbsp;</td>
  </tr>
  <tr>
    <td width="62" height="38" align="center" valign="top" class="style2">Note :     </td>
    <td width="323" align="left" valign="top"><span class="style3">{note}</span></td>
  </tr>
</table>
{/company}
</body>
</html>
