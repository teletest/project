<ul>
{tabs}
<li{class}><a href="{tab_url}"><span><span>{tab_title}</span></span></a></li>
{/tabs}
</ul>