<!-- search form -->

<div id="searchtab">
  <div class="inside">
    <form method="get" id="searchform" action="">
      <input type="text" name="s" id="searchbox" size="16" class="searchfield" value="Search website..." onfocus="if(this.value == 'Search website...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search website...';}" />
       <input type="submit" value="Go" class="searchbutton" />
    </form>
  </div>
</div>

<!-- /search form -->