<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class MY_Entity extends Controller
{
	function My_Entity()
	{
		parent::Controller();

		
	}
	
	function Add()
	{
		// Display a form for editing		
	
		test();
	}
	
	function Show()
	{
		// Display a list	
		
	}
	
	
	

}	
		