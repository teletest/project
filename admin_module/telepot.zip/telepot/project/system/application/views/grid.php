<html>
<head>
<title>Flexigrid Implemented in CodeIgniter</title>
<script type="text/javascript" src="<?=$this->config->item('base_url');?>public/js/jquery.pack.js"></script>
<script type="text/javascript" src="<?=$this->config->item('base_url');?>public/js/flexigrid.pack.js"></script>
</head>
<body>

<?=$js_grid;?>

<table id="flex1" style="display:none"></table>

</body>
</html> 

