-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 27, 2010 at 05:16 PM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `old_teletest`
--

-- --------------------------------------------------------

--
-- Table structure for table `acquisitions`
--

CREATE TABLE IF NOT EXISTS `acquisitions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` varchar(25) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `nominal_latitude` int(11) NOT NULL,
  `nominal_longitude` int(11) NOT NULL,
  `candidate` varchar(25) NOT NULL,
  `latitude` int(11) NOT NULL,
  `longitude` int(11) NOT NULL,
  `candidate_distance` int(11) NOT NULL,
  `owner_details` text NOT NULL,
  `site_type` varchar(25) NOT NULL,
  `clutter_type` varchar(25) NOT NULL,
  `address` text NOT NULL,
  `legal_status` text NOT NULL,
  `legal_documents` text NOT NULL,
  `act_remarks` text NOT NULL,
  `act_responsible` varchar(100) NOT NULL,
  `followup_status` text NOT NULL,
  `summary` text NOT NULL,
  `rent` int(11) NOT NULL,
  `approval1` tinyint(1) NOT NULL,
  `approval2` tinyint(1) NOT NULL,
  `approval3` tinyint(1) NOT NULL,
  `approval4` tinyint(1) NOT NULL,
  `approval5` tinyint(1) NOT NULL,
  `power_connection` tinyint(1) NOT NULL,
  `gen_set` tinyint(1) NOT NULL,
  `others` tinyint(1) NOT NULL,
  `date_submit` date NOT NULL,
  `date_leasepo_planned` date NOT NULL,
  `date_leasepo_received` date NOT NULL,
  `site_secured` text NOT NULL,
  `date_secured` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `acquisitions`
--


-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `type` enum('RND','Acquisition','Transmission','Civil Works','Telecom','Other') NOT NULL DEFAULT 'Other',
  `subject` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `comments` text NOT NULL,
  `activity_by` int(11) NOT NULL,
  `activity_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `project_id`, `site_id`, `candidate_id`, `type`, `subject`, `desc`, `comments`, `activity_by`, `activity_on`) VALUES
(1, 2, 1, 1, 'RND', 'Test', 'Its a test activity', 'Passed', 0, '2009-05-07'),
(2, 1, 1, 2, 'Other', 'Another Activity', 'Its a test activity', 'Failed', 0, '2009-05-05');

-- --------------------------------------------------------

--
-- Table structure for table `attachements`
--

CREATE TABLE IF NOT EXISTS `attachements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `attached_on` date NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `attachements`
--

INSERT INTO `attachements` (`id`, `project_id`, `filename`, `attached_on`, `is_active`) VALUES
(1, 11, 'helloworld.txt', '2009-05-06', 1),
(2, 11, 'someother.txt', '2009-05-01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE IF NOT EXISTS `candidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `code` varchar(25) NOT NULL,
  `latitude` int(11) NOT NULL,
  `longitude` int(11) NOT NULL,
  `candidate_distance` int(11) NOT NULL,
  `approval1` tinyint(1) NOT NULL,
  `approval2` tinyint(1) NOT NULL,
  `approval3` tinyint(1) NOT NULL,
  `approval4` tinyint(1) NOT NULL,
  `approval5` tinyint(1) NOT NULL,
  `power_connection` tinyint(1) NOT NULL,
  `gen_set` tinyint(1) NOT NULL,
  `others` tinyint(1) NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `site_id`, `code`, `latitude`, `longitude`, `candidate_distance`, `approval1`, `approval2`, `approval3`, `approval4`, `approval5`, `power_connection`, `gen_set`, `others`, `isactive`) VALUES
(1, 1, 'A', 100001, 100001, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(2, 1, 'B', 100002, 100002, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('97b84f6ae4f2584f55a0d72b24346b98', '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_6; ', 1242733294, 'a:4:{s:2:"id";s:5:"admin";s:4:"user";s:13:"Administrator";s:9:"logged_in";s:1:"1";s:8:"is_admin";s:1:"1";}');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` tinytext NOT NULL,
  `profile` text NOT NULL,
  `note` text NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `address`, `profile`, `note`, `isactive`) VALUES
(1, 'NeoSense', '#1 Toorabad,\r\nSialkot\r\nPakistan', 'profile', 'note', 1),
(2, 'Teletest', 'On the net', '', '', 1),
(4, 'Test', 'Address of Test', 'Test Profile', 'Test Note', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL,
  `contact_type` enum('','Telephone','Mobile','Fax','Email','Web','Other') DEFAULT NULL,
  `contact_detail` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `company_id`, `person_id`, `contact_type`, `contact_detail`) VALUES
(1, 1, NULL, 'Telephone', '00 92 52 35 75 366'),
(2, 1, NULL, 'Email', 'email@neosense.com'),
(3, 1, NULL, 'Web', 'http://neosense.com'),
(4, 2, NULL, 'Email', 'teletest.case@googlemail.com'),
(5, NULL, 1, 'Email', 'email@irfantoor.com');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `isactive`) VALUES
(1, 'Administrator', 1),
(2, 'User', 1),
(3, 'Guest', 1);

-- --------------------------------------------------------

--
-- Table structure for table `group_user`
--

CREATE TABLE IF NOT EXISTS `group_user` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_user`
--

INSERT INTO `group_user` (`group_id`, `user_id`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE IF NOT EXISTS `options` (
  `id` varchar(25) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `value`) VALUES
('admin_user', 'admin'),
('debug_mode', '0'),
('cal_starttime', '09:00'),
('cal_endtime', '17:00'),
('cal_workingdays', '1,2,3,4,5,6'),
('smtp_host', 'localhost'),
('smtp_port', '25'),
('smtp_username', 'smtp_username'),
('smtp_password', 'smtp_password'),
('smtp_server_timeout', '30'),
('smtp_isactive', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `persons`
--

CREATE TABLE IF NOT EXISTS `persons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `company_id` int(11) NOT NULL,
  `login` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valid_from` date NOT NULL,
  `valid_untill` date NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  `email` varchar(100) NOT NULL,
  `email_signature` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `persons`
--

INSERT INTO `persons` (`id`, `name`, `company_id`, `login`, `password`, `group_id`, `created_on`, `valid_from`, `valid_untill`, `isactive`, `email`, `email_signature`) VALUES
(1, 'Administrator', 0, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, '2009-03-05 20:10:46', '2009-01-01', '2009-12-31', 1, '', ''),
(2, 'Irfan TOOR', 1, 'irfan', '7b24afc8bc80e548d66c4e7ff72171c5', 1, '2009-03-05 20:10:46', '2009-01-01', '2009-01-31', 1, 'email@irfantoor.com', '-it'),
(5, 'Hello World', 2, 'hello', 'd41d8cd98f00b204e9800998ecf8427e', 1, '2009-04-19 13:31:44', '2009-01-01', '2009-12-31', 1, 'email@irfantoor.com', 'email sig');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(25) NOT NULL,
  `desc` tinytext NOT NULL,
  `status` enum('Created','Planned','Active','Inactive','Completed') NOT NULL DEFAULT 'Created',
  `created_on` date NOT NULL,
  `planned_on` date NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `activated_on` date NOT NULL,
  `completed_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `code`, `desc`, `status`, `created_on`, `planned_on`, `start_date`, `end_date`, `activated_on`, `completed_on`) VALUES
(10, 'HW2', 'Hello World 2 is a tes project and will be executed\nin the northern region of the country', 'Created', '2009-05-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00'),
(2, 'HW', 'Hello World', 'Active', '2009-05-01', '2009-05-02', '2009-05-03', '2009-05-31', '2009-05-03', '0000-00-00'),
(11, 'Warid', 'Site at Toorabad', 'Planned', '2009-05-05', '2009-05-06', '2009-05-14', '2009-06-15', '0000-00-00', '0000-00-00'),
(12, 'T2', 'Its a Test Project', 'Created', '2009-05-03', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE IF NOT EXISTS `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `division` varchar(25) NOT NULL,
  `district` varchar(25) NOT NULL,
  `msc` varchar(25) NOT NULL,
  `bsc` varchar(25) NOT NULL,
  `owner_details` text NOT NULL,
  `address` text NOT NULL,
  `nominal_latitude` int(11) NOT NULL,
  `nominal_longitude` int(11) NOT NULL,
  `cell_id` varchar(15) NOT NULL,
  `eirp` int(11) NOT NULL,
  `erp` int(11) NOT NULL,
  `antenna_type` varchar(25) NOT NULL,
  `electric_tilt` varchar(25) NOT NULL,
  `mechanical_tilt` varchar(25) NOT NULL,
  `azimuths` varchar(100) NOT NULL,
  `phase` varchar(25) NOT NULL,
  `region` varchar(25) NOT NULL,
  `site_type` varchar(25) NOT NULL,
  `capacity` varchar(10) NOT NULL,
  `height` int(11) NOT NULL,
  `clutter_type` varchar(25) NOT NULL,
  `status` varchar(25) NOT NULL,
  `objectives` text NOT NULL,
  `analysis` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sites`
--

INSERT INTO `sites` (`id`, `project_id`, `name`, `division`, `district`, `msc`, `bsc`, `owner_details`, `address`, `nominal_latitude`, `nominal_longitude`, `cell_id`, `eirp`, `erp`, `antenna_type`, `electric_tilt`, `mechanical_tilt`, `azimuths`, `phase`, `region`, `site_type`, `capacity`, `height`, `clutter_type`, `status`, `objectives`, `analysis`) VALUES
(1, 2, 'Hello World', 'Punjab', 'Sialkot', 'MSC-01', 'BSC-01', 'Mr. Owner', 'Toorabad', 100000, 100000, '1', 0, 0, '', '', '', '', '', '', '', '', 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `surveys`
--

CREATE TABLE IF NOT EXISTS `surveys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `category` enum('RND','Transmition') NOT NULL,
  `type` enum('Scoping','Intermediate','PSS') NOT NULL,
  `area` varchar(25) NOT NULL,
  `latitude` int(11) NOT NULL,
  `longitude` int(11) NOT NULL,
  `candidate_distance` int(11) NOT NULL,
  `proposed_antenna_height` int(11) NOT NULL,
  `antenna_height` int(11) NOT NULL,
  `site_type` varchar(25) NOT NULL,
  `clutter_type` varchar(25) NOT NULL,
  `building_height` int(11) NOT NULL,
  `parapet_height` int(11) NOT NULL,
  `rbs_type` varchar(25) NOT NULL,
  `structure_type` varchar(25) NOT NULL,
  `structure_height` int(11) NOT NULL,
  `azimuths` varchar(25) NOT NULL,
  `tilt` varchar(25) NOT NULL,
  `feeder_type` varchar(25) NOT NULL,
  `feeder_length` int(11) NOT NULL,
  `site_objective` text NOT NULL,
  `site_address` text NOT NULL,
  `coverage_area_prediction` text NOT NULL,
  `coverage_area1` text NOT NULL,
  `coverage_area2` text NOT NULL,
  `coverage_area3` text NOT NULL,
  `ranking` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `engineer` int(11) NOT NULL,
  `status` text NOT NULL,
  `reason` text NOT NULL,
  `comments` text NOT NULL,
  `summary` text NOT NULL,
  `survey_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `surveys`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `login` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valid_from` date NOT NULL,
  `valid_untill` date NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

