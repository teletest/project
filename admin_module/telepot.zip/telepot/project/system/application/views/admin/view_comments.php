<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style10 {font-family: tahoma; font-weight: bold; font-size: 12px; }
.style12 {font-family: tahoma; font-size: 12px; }
-->
</style>
</head>

<body>
{cur_feedback}
<table width="391" height="208" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="14" height="30">&nbsp;</td>
    <td width="138" height="30"><span class="style10">From : </span></td>
    <td width="239" height="30"><span class="style12">{from}</span></td>
  </tr>
   <tr>
    <td width="14" height="30">&nbsp;</td>
    <td width="138" height="30"><span class="style10">Company : </span></td>
    <td width="239" height="30"><span class="style12">{company}</span></td>
  </tr> 
  <tr>
    <td height="30">&nbsp;</td>
    <td height="30"><span class="style10">Posted Date : </span></td>
    <td height="30"><span class="style12">{cur_date}</span></td>
  </tr>
  <tr>
    <td height="37">&nbsp;</td>
    <td height="37"><span class="style10">Subject : </span></td>
    <td height="37"><span class="style12">{subject}</span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td valign="top"><span class="style10">Comments : </span></td>
    <td align="left" valign="top"><span class="style12">{comments}</span></td>
  </tr>
</table>
{/cur_feedback}
</body>
</html>
