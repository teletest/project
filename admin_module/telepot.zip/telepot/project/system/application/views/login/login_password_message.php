<?php
$this->load->view('header');
?>

<h2>{page_title}</h2>

<p class="error">{msg}</p>

<?php 
$this->load->view('footer');
?>