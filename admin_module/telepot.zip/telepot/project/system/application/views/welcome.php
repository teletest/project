<?php  $this->load->view('header');  ?>


<div id="main-content">
<div id="logut" style="float:left;">
<h3>Logut</h3>
<a href="<?php echo site_url('/login/logout/') ?>">Click here to logout.</a>
</div>
<div style="float:left;margin-left:20px;">
Welcome to Home Page
</div>
</div>


<?php $this->load->view('footer'); ?>