<!-- top note -->
	<li><h2>Project Note</h2>
	<p>Teletest Case is a Pilot project undertaken by NeoSense Inc. for a period of one month.</p>
	<p>It is a challenge in its definition, its duration and is beating 'Blair witch project' on its financial ressources.</p>
	</li>
<!-- /top note -->